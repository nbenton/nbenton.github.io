module type CCC =
sig
  type ('a,'b) hom
  type one
  type ('a,'b) prod
  type ('a,'b) exp

  val id : ('a,'a) hom
  val compose : ('a,'b) hom -> ('b,'c) hom -> ('a,'c) hom

  val one : ('a,one) hom

  val fst : (('a,'b) prod, 'a) hom 
  val snd : (('a,'b) prod, 'b) hom 
  val pair : ('a,'b) hom -> ('a,'c) hom -> ('a, ('b,'c) prod) hom

  val curry : (('a,'b) prod, 'c) hom -> ('a, ('b,'c) exp) hom
  val eval : ((('a,'b) exp, 'a) prod, 'b) hom
end

module type COKLEISLI =
sig
  include CCC

  type ('a,'b) shrink
  val sweak     : ('a, ('b,'a) shrink) hom
  val spair     : ((('a,'b) shrink, ('a,'c) shrink) prod, ('a,('b,'c) prod) shrink) hom
  val scurry    : ((('a,'b) prod, 'c) shrink, ('a,('b,'c) shrink) shrink) hom
  val scomposer : ('a,'b) hom -> (('c,'a) shrink, ('c,'b) shrink) hom
  val scomposel : ('a,'b) hom -> (('b,'c) shrink, ('a,'c) shrink) hom
  val seval     : ((('a, ('b,'c) shrink) shrink, ('a,'b) exp) prod, ('a,'c) shrink) hom
  val swap      : (('a, ('b, 'c) shrink) exp, ('b, ('a, 'c) exp) shrink) hom 
  val swap'     : (('a, ('b, 'c) exp) shrink, ('b, ('a, 'c) shrink) exp) hom
  val eval'     : ((('a,'b) shrink, 'a) prod, 'b) hom
end

module type ULTRAMETRIC =
sig
  include COKLEISLI

  type 'a discrete
  val discrete : ('a -> 'b) -> ('a discrete, 'b discrete) hom
  val const : 'a -> ('b, 'a discrete) hom 
end

(* This module extends the datflow expression monad with some reader state 
   to make everything parametric in the clock and the update list. *)
module Code =
struct
  module D = Dataflow.Expr

  type clock = unit Dataflow.cell
  type updates = unit D.t list ref
  type state = clock * updates
  type 'a code = state -> 'a D.t 

  let return x s = D.return x 
  let read cell s = D.read cell
  let (>>=) m f s = D.bind (m s) (fun v -> f v s)
  let newref v s = D.local (fun () -> ref v)
  let get r s = D.local (fun () -> !r)
  let set r v s = D.local (fun () -> r := v)
  let local thunk s = D.local thunk

  let cell code s = D.newcell (code s)
  let clock (clock, _) = D.read clock
  let register cell (_, updates) =
    let poke = D.bind (D.read cell) (fun _ -> D.return ()) in
    updates := poke :: !updates;
    D.return ()

 (* Some utility functions for dealing with optionals *)
  let ozip = function 
    | Some x, Some y -> Some(x,y)
    | _ -> None

  let omap f = function
    | None -> None
    | Some v -> Some(f v)

  let (>>-) m f = m >>= (function None -> return None
                         | Some v -> f v)

  let (>>!) m f = m >>= (function None -> assert false
                         | Some v -> f v)
end

module U =
struct
  (* The lazy implementation of ultrametrics... *)
  open Code

  type one = unit
  type ('a,'b) prod = 'a * 'b
  type ('a,'b) exp = 'a option code -> 'b option code
  type ('a,'b) hom = 'a option code -> 'b option code
  type ('a,'b) shrink = 'a option code-> 'b option code
  type 'a discrete = 'a 

  let id x = x
  let compose f g = fun xt -> g(f xt)
  let one = fun _ -> return(Some ())
  let pair f g = fun at -> f at >>- (fun a ->
			     g at >>- (fun b ->
			     return(Some (a,b))))
  let fst = fun abt -> abt >>- (fun (a,b) -> return(Some a))
  let snd = fun abt -> abt >>- (fun (a,b) -> return(Some b))
  (* Double-check this... *)
  let curry f = fun at -> return(Some(fun bt ->
				  f (at >>- (fun a ->
				     bt >>- (fun b ->
				     return (Some(a,b)))))))

  (* Ouch! We get no sharing *at all* *)
  let eval = fun fxt -> (fxt >>- (fun (f,x) ->
			   f (fxt >>- fun (_,x) -> 
                            return (Some x))))
	
  let discrete f xt = xt >>- (fun x ->
		        return (Some (f x)))

  let const x = fun _ -> return(Some x)
    
  (* The contractive operations can be implemented exactly as if
     they were the curried forms of the standard exponential ops.
     This is because we make ZERO effort to be eager. If we
     made any effort in this direction at all, then we would need to
     reimplement these combinators because we would risk losing 
     answers along the pipeline. 
  *)
  let sweak xs = (curry fst) xs

  let spair xs =
    let f = compose (pair (compose fst fst) snd) eval in
    let g = compose (pair (compose fst snd) snd) eval in
    (curry (pair f g)) xs

  let scurry xs =
    let f = compose fst fst in 
    let a = compose fst snd in
    let b = snd in
    let c = compose (pair f (pair a b)) eval in
    (curry (curry c)) xs

  let eval'  = eval 

  let seval xs =
    let f = compose fst fst in
    let g = compose fst snd in
    let a = snd in
    let fa = compose (pair f a) eval in
    let ga = compose (pair g a) eval in
    let c = compose (pair fa ga) eval in
    (curry c) xs

  let swap xs =
    let f = compose fst fst in
    let a = snd in 
    let b = compose fst snd in
    let fa = compose (pair f a) eval in
    let c = compose (pair fa b) eval in
    (curry (curry c)) xs

  let swap' = swap

  let scomposer f = curry (compose eval f)

  let scomposel f = curry (compose (pair fst (compose snd f)) eval)
end    					 


 Strict implementation....doesn't work (yet?)
  module U =
  struct
    open Code

    type one = unit
    type ('a,'b) prod = 'a * 'b
    type ('a,'b) exp = 'a -> 'b code
    type ('a,'b) hom = 'a -> 'b code
    type ('a,'b) shrink = 'a -> 'b code
    type 'a discrete = 'a 

    let id x = return x
    let compose f g x = (f x) >>= (fun y -> g y)

    let one = fun _ -> return ()
    let fst = fun (a,b) -> return a
    let snd = fun (a,b) -> return b
    let pair f g a = (f a) >>= (fun u ->
                     (g a) >>= (fun v -> 
                     return (u,v)))
    let curry f  = fun a -> return (fun b -> f(a,b))
    let eval (f,x) = f x

    let discrete f x = return (f x)

    (* The contractive operations can be implemented exactly as if
       they were the curried forms of the standard exponential ops. 
       The definitions which follow are essentially just the compilation
       of lambda terms into categorical combinators, plus an eta-expansion
       to make Ocaml's value restriction happy.
    *)
    let sweak xs = (curry fst) xs

    let spair xs =
      let f = compose (pair (compose fst fst) snd) eval in
      let g = compose (pair (compose fst snd) snd) eval in
      (curry (pair f g)) xs

    let scurry xs =
      let f = compose fst fst in 
      let a = compose fst snd in
      let b = snd in
      let c = compose (pair f (pair a b)) eval in
      (curry (curry c)) xs

    let eval'  = eval 

    let seval xs =
      let f = compose fst fst in
      let g = compose fst snd in
      let a = snd in
      let fa = compose (pair f a) eval in
      let ga = compose (pair g a) eval in
      let c = compose (pair fa ga) eval in
      (curry c) xs

    let swap xs =
      let f = compose fst fst in
      let a = snd in 
      let b = compose fst snd in
      let fa = compose (pair f a) eval in
      let c = compose (pair fa b) eval in
      (curry (curry c)) xs

    let swap' = swap

    let scomposer f = curry (compose eval f)

    let scomposel f = curry (compose (pair fst (compose snd f)) eval)
  end

                        
module C =
struct
  open Code
  type 'a stream = 'a option Dataflow.cell

  type one = unit
  type ('a,'b) prod = 'a * 'b
  type ('a,'b) exp = 'a stream -> 'b stream code
  type ('a,'b) shrink = 'a stream -> 'b stream code
  type ('a,'b) hom = 'a stream -> 'b stream code

  (* This should be type-indexed, to get finer dependency tracking. In Haskell,
     we could use the type function mechanism to implement this!  
   *)

  let zip xs ys = (read xs) >>= (fun x' -> 
                  (read ys) >>= (fun y' ->
                    match x', y' with
                    | None, None
                    | Some _, Some _ -> cell ((read xs) >>= fun x' -> 
                                              (read ys) >>= fun y' ->
                                              return (ozip (x', y')))
                    | None, Some _ ->
                        (newref None) >>= (fun r ->
                        (cell ((read xs) >>= (fun x ->
                               (read ys) >>= (fun newval ->
                               (get r) >>= (fun oldval ->
                               (set r newval) >>= (fun () ->
                               return (ozip(x, oldval)))))))) >>= (fun xys ->
                        (register xys) >>= (fun () ->
                        return xys)))
                    | Some _, None -> 
                        (newref None) >>= (fun r ->
                        (cell ((read ys) >>= (fun y ->
                               (read xs) >>= (fun newval ->
                               (get r) >>= (fun oldval ->
                               (set r newval) >>= (fun () ->
                               return (ozip(oldval, y)))))))) >>= (fun xys ->
                        (register xys) >>= (fun () ->
                        return xys)))))

  let id xs = return xs
  let compose f g xs = (f xs) >>= g

  let one xs = cell(return(Some ()))
  let pair f g xs = (f xs) >>= (fun ys ->
                    (g xs) >>= (fun zs ->
                      zip ys zs))
  let fst abs = cell ((read abs) >>- (fun (a,b) -> return (Some a)))
  let snd abs = cell ((read abs) >>- (fun (a,b) -> return (Some b)))
  let eval fxs = (fst fxs) >>= (fun fs ->
                 (snd fxs) >>= (fun xs ->
                 cell ((read fs) >>- (fun f -> (f xs) >>= read))))
  let curry f = fun xs -> cell(read xs >>- (fun _ -> 
                               return (Some(fun ys -> (zip xs ys) >>= f))))

  let sweak xs = cell(return(Some(fun ys -> return xs)))
  let spair fgs = cell((read fgs) >>- (fun (f,g) -> return(Some(pair f g))))
  let scurry fs = cell(return(Some(fun xs -> 
                  cell(return(Some(fun ys ->
                  cell(read fs >>- (fun f -> 
                       zip xs ys >>= (fun xys -> 
                       f xys >>= read)))))))))

                    
  let scomposer f gs = cell(read gs >>- (fun g -> return(Some(compose g f))))
  let scomposel f gs = cell(read gs >>- (fun g -> return(Some(compose f g))))

  let seval fgs = cell(read fgs >>- (fun (f,g) ->
                       return(Some(fun gammas ->
                                     (g gammas) >>= (fun bs ->
                                     (f gammas) >>= (fun hs ->
                                       cell((read hs) >>- (fun h ->
                                            (h bs) >>= (fun cs ->
                                            read cs)))))))))

  let swap fs =
    (curry (curry (compose
                     (pair (compose (pair (compose fst fst) snd) eval)
                           (compose fst snd))
                     eval)))
    fs
  let swap' = swap

  let eval' = eval
end

open Code
type 'a omega = 'a option Dataflow.cell
type 'a value = 'a

(* Functorial actions *)

let value uhom = fun xs -> cell(uhom (read xs))

let omega chom = fun xt -> xt >>- (fun xs ->
			     chom xs >>= (fun ys ->
			     return(Some ys)))

(* Unit & Counit *)

let varepsilon xst = xst >>- read
let eta xs = cell((read xs) >>- (fun _ -> return (Some xs)))

let one' _ = 
  cell(return(Some ())) >>= (fun unit ->
  return(Some(unit)))

let prod xycst = xycst >>- (fun xys ->
		   cell(read xys >>- (fun (a,b) -> return(Some a))) >>= (fun xs -> 
		   cell(read xys >>- (fun (a,b) -> return(Some b))) >>= (fun ys -> 
                 return(Some(xs, ys)))))

let prod' xsyst = xsyst >>- (fun (xs,ys) ->
		    cell(read xs >>- (fun x -> 
			 read ys >>- (fun y ->
			 return(Some(x,y))))) >>= (fun xys ->
		    return(Some xys)))

let oned   = fun thunk -> thunk
let paird  = fun thunk -> thunk
let paird' = fun thunk -> thunk

let fix ft = ft >>- (fun (f : ('a omega, 'a omega) U.shrink) ->
	       newref None >>= (fun (r : 'a option ref) ->
	       cell(clock >>= (fun () -> get r)) >>= (fun (input : 'a omega) -> 
             register input >>= (fun () -> 
             f (return (Some input)) >>= (function
	       | None -> assert false 
	       | Some (pre : 'a omega) ->  (* sketchy! *)
	       cell(clock >>= (fun () ->
		    read input >>= (fun _ -> 
		    read pre >>= (fun v ->
		    set r v >>= (fun () ->
		    return v))))) >>= (fun output -> 
             register output >>= (fun () -> 
             return (Some output))))))))

let cons xt =
  xt >>- (fun x ->
  return(Some(fun xst ->
		  newref (Some x) >>= (fun (r : 'a option ref) ->
		  newref None >>= (fun (xsr : 'a option Dataflow.cell option ref) ->  
		  cell( get r >>= (fun oldval ->
		       (get xsr >>= fun v ->
			match v with
			| Some xs -> return(Some xs)
			| None -> xst >>= (fun xs' ->
				  set xsr xs' >>= (fun () ->
				  return xs'))) >>= (fun xs' ->
		       (get xsr >>= (fun xs' ->
			match xs' with
			| None -> return None
			| Some xs -> read xs)) >>= (fun newval ->
		       match oldval with
		       | None -> return newval
		       | Some _ -> set r newval >>= (fun () ->
				   return oldval))))) >>= (fun output ->
		   register output >>= (fun () ->
		   return (Some output))))))))

let run (uhom : ((C.one omega, U.one) U.prod, 'a U.discrete value omega) U.hom) = 
  let clock = Dataflow.newcell (Dataflow.Expr.return ()) in
  let updates = ref [] in
  let ones = Dataflow.newcell (Dataflow.Expr.return (Some ())) in
  let empty_context = return (Some (ones, ())) in 
  let output = match Dataflow.eval (uhom empty_context (clock, updates)) with
               | None -> assert false
		 | Some output -> output
  in
  let step () =
    begin
      Dataflow.update clock (Dataflow.Expr.return ());
      let v = Dataflow.eval (Dataflow.Expr.read output) in
      (List.iter Dataflow.eval !updates; v)
    end
  in step
