#!/bin/bash

#check arguments

if [ $# -lt 1 ]
then
  echo "Usage: `basename $0` <coq source file 1>..."
  exit 1
fi


for i
do
  DEPS=`grep "Require Import" $i | sed 's/Require Import \([^.]*\)./\1/'`
  DEPS=$DEPS" `grep "Require Export" $i | sed 's/Require Export \([^.]*\)./\1/'`"

  LOCAL=`ls *.v | sed 's/.v//g'`

  DEP_FILES=""

  for file in $LOCAL
  do
          for dep in $DEPS
          do
            if [ "$file" == "$dep" ]
            then
              DEP_FILES="$DEP_FILES $file"
            fi
         done
  done

  DEPS=$DEP_FILES

  if [ "$DEPS" != "" ]
  then
    DEPS=`echo $DEPS | sed 's/ /.vo /g'`
    DEPS=`echo $DEPS | sed 's/$/.vo /g'`
    DEPS=`echo $DEPS | sed 's/ \.vo//g'`
  fi

  TARGET=`echo $i | sed 's/.v$/.vo/'`

  echo $TARGET: $i $DEPS
  echo
done

