module type CCC =
sig
  type ('a,'b) hom
  type one
  type ('a,'b) prod
  type ('a,'b) exp

  val id : ('a,'a) hom
  val compose : ('a,'b) hom -> ('b,'c) hom -> ('a,'c) hom

  val one : ('a,one) hom

  val fst : (('a,'b) prod, 'a) hom 
  val snd : (('a,'b) prod, 'b) hom 
  val pair : ('a,'b) hom -> ('a,'c) hom -> ('a, ('b,'c) prod) hom

  val curry : (('a,'b) prod, 'c) hom -> ('a, ('b,'c) exp) hom
  val eval : ((('a,'b) exp, 'a) prod, 'b) hom
end

module type CONTRACTIVE =
sig
  include CCC
  type ('a,'b) shrink
  val sweak     : ('a, ('b,'a) shrink) hom
  val spair     : ((('a,'b) shrink, ('a,'c) shrink) prod, ('a,('b,'c) prod) shrink) hom
  val scurry    : ((('a,'b) prod, 'c) shrink, ('a,('b,'c) shrink) shrink) hom
  val scomposer : ('a,'b) hom -> (('c,'a) shrink, ('c,'b) shrink) hom
  val scomposel : ('a,'b) hom -> (('b,'c) shrink, ('a,'c) shrink) hom
  val seval     : ((('a, ('b,'c) shrink) shrink, ('a,'b) exp) prod, ('a,'c) shrink) hom
  val swap      : (('a, ('b, 'c) shrink) exp, ('b, ('a, 'c) exp) shrink) hom 
  val swap'     : (('a, ('b, 'c) exp) shrink, ('b, ('a, 'c) shrink) exp) hom
  val eval'     : ((('a,'b) shrink, 'a) prod, 'b) hom
end

module type COKLEISLI = 
sig
  include CONTRACTIVE
end 

module type ULTRAMETRIC =
sig
  include COKLEISLI

  type ('a,'b) sum
  val inl : ('a, ('a,'b) sum) hom 
  val inr : ('b, ('a,'b) sum) hom 
  val case : ('a,'b) hom -> ('c,'b) hom -> (('a,'c) sum, 'b) hom 
    
  type 'a discrete
  val discrete : ('a -> 'b) -> ('a discrete, 'b discrete) hom
  val const : 'a -> ('b, 'a discrete) hom 

  type 'a gui
  val return   : ('a, 'a gui) hom
  val bind     : ('a,'b gui) hom -> ('a gui, 'b gui) hom
  val strength : (('a, 'b gui) prod, ('a,'b) prod gui) hom 
end



(* This module extends the datflow expression monad with some reader state 
   to make everything parametric in the clock and the update list. *)
module Code =
struct
  module D = Dataflow.Expr

  type clock = unit Dataflow.cell
  type updates = unit D.t list ref
  type state = clock * updates
  type 'a code = state -> 'a D.t 

  let return x s = D.return x 
  let return' x s = D.return (Some x)

  let read cell s = D.read cell
  let (>>=) m f s = D.bind (m s) (fun v -> f v s)
  let newref v s = D.local (fun () -> ref v)
  let get r s = D.local (fun () -> !r)
  let set r v s = D.local (fun () -> r := v)
  let local thunk s = D.local thunk

  let get_clock (clock, _) = D.return clock

  let cell code s = D.newcell (code s)
  let clock (clock, _) = D.read clock
  let register cell (_, updates) =
    let poke = D.bind (D.read cell) (fun _ -> D.return ()) in
    updates := poke :: !updates;
    D.return ()

  let fix f s =
    D.fix (fun c -> f (fun _ -> c) s)

 (* Some utility functions for dealing with optionals *)
  let ozip = function 
    | Some x, Some y -> Some(x,y)
    | _ -> None

  let omap f = function
    | None -> None
    | Some v -> Some(f v)

  let ofold none some = function
    | None -> none
    | Some v -> some v

  let (>>-) m f = m >>= (function None -> return None
                         | Some v -> f v)

  let (>>!) m f = m >>= (function None -> assert false
                         | Some v -> f v)
end


module C =
struct
  open Code
  type 'a stream = 'a option Dataflow.cell

  type one = unit
  type ('a,'b) prod = 'a * 'b
  type ('a,'b) exp = 'a stream -> 'b stream code
  type ('a,'b) shrink = 'a stream -> 'b stream code
  type ('a,'b) hom = 'a stream -> 'b stream code

  (* This should be type-indexed, to get finer dependency tracking. In Haskell,
     we could use the type function mechanism to implement this!  
   *)

  let zip xs ys = (read xs) >>= (fun x' -> 
                  (read ys) >>= (fun y' ->
                    match x', y' with
                    | None, None
                    | Some _, Some _ -> cell ((read xs) >>= fun x' -> 
                                              (read ys) >>= fun y' ->
                                              return (ozip (x', y')))
                    | None, Some _ ->
                        (newref None) >>= (fun r ->
                        (cell ((read xs) >>= (fun x ->
                               (read ys) >>= (fun newval ->
                               (get r) >>= (fun oldval ->
                               (set r newval) >>= (fun () ->
                               return (ozip(x, oldval)))))))) >>= (fun xys ->
                        (register xys) >>= (fun () ->
                        return xys)))
                    | Some _, None -> 
                        (newref None) >>= (fun r ->
                        (cell ((read ys) >>= (fun y ->
                               (read xs) >>= (fun newval ->
                               (get r) >>= (fun oldval ->
                               (set r newval) >>= (fun () ->
                               return (ozip(oldval, y)))))))) >>= (fun xys ->
                        (register xys) >>= (fun () ->
                        return xys)))))

  let id xs = return xs
  let compose f g xs = (f xs) >>= g

  let one xs = cell(return(Some ()))
  let pair f g xs = (f xs) >>= (fun ys ->
                    (g xs) >>= (fun zs ->
                      zip ys zs))
  let fst abs = cell ((read abs) >>- (fun (a,b) -> return (Some a)))
  let snd abs = cell ((read abs) >>- (fun (a,b) -> return (Some b)))
  let eval fxs = (fst fxs) >>= (fun fs ->
                 (snd fxs) >>= (fun xs ->
                 cell ((read fs) >>- (fun f -> (f xs) >>= read))))
  let curry f = fun xs -> cell(read xs >>- (fun _ -> 
                               return (Some(fun ys -> (zip xs ys) >>= f))))

  let sweak xs = cell(return(Some(fun ys -> return xs)))
  let spair fgs = cell((read fgs) >>- (fun (f,g) -> return(Some(pair f g))))
  let scurry fs = cell(return(Some(fun xs -> 
                  cell(return(Some(fun ys ->
                  cell(read fs >>- (fun f -> 
                       zip xs ys >>= (fun xys -> 
                       f xys >>= read)))))))))

                    
  let scomposer f gs = cell(read gs >>- (fun g -> return(Some(compose g f))))
  let scomposel f gs = cell(read gs >>- (fun g -> return(Some(compose f g))))

  let seval fgs = cell(read fgs >>- (fun (f,g) ->
                       return(Some(fun gammas ->
                                     (g gammas) >>= (fun bs ->
                                     (f gammas) >>= (fun hs ->
                                       cell((read hs) >>- (fun h ->
                                            (h bs) >>= (fun cs ->
                                            read cs)))))))))

  let swap fs =
    (curry (curry (compose
                     (pair (compose (pair (compose fst fst) snd) eval)
                           (compose fst snd))
                     eval)))
    fs
  let swap' = swap

  let eval' = eval
end


module U =
struct
  (* The strict implementation of ultrametrics...this is much better, but 
     the proof isn't finished yet. *)
  open Code

  type one = unit
  type ('a,'b) prod = 'a * 'b
  type ('a,'b) sum = Inl of 'a | Inr of 'b 
  type 'a discrete = 'a 

  (* Note that contractives and ordinary functions are *different* types. 
     Shrinking maps are lazy, and ordinary maps are strict, and furthermore,
     shrinking maps never fail! *)
  type ('a,'b) exp = 'a -> 'b option code
  type ('a,'b) hom = 'a -> 'b option code
  type ('a,'b) shrink = 'a option code-> 'b code

  (* The implementation of GTK guis! *)
  type 'a gui = (GObj.widget -> unit) -> 'a option code 

  let id x = return' x
  let compose f g = fun x -> f x >>- g 
  let one = fun _ -> return' ()
  let pair f g = fun at -> f at >>- (fun a ->
                           g at >>- (fun b ->
                           return' (a,b)))
  let fst = fun (a,b) -> return' a
  let snd = fun (a,b) -> return' b 

  (* Double-check case... *)

  let inl = fun v -> return' (Inl v)
  let inr = fun v -> return' (Inr v)

  let case (f : ('a,'b) hom) (g : ('c,'b) hom) = function
    | Inl v -> f v
    | Inr v -> g v

  let curry f = fun a -> return'(fun b -> f(a,b)) 

  let eval (f,x) = f x

  let discrete f = fun x -> return' (f x)

  let const x = fun _ -> return' x
    
  (* The contractive operations must be implemented lazily, since  
     we need to be able to re-evaluate the input in case it is 
     currently undefined. Also, we need to impedance-match options & 
     non-options. 
  *)
  let sweak = fun x -> return' (fun _ -> return x)

  let spair = fun (f,g) -> return' (fun xt -> f xt >>= (fun y ->  
                                              g xt >>= (fun z -> 
                                              return (y,z))))
  let scurry = fun f -> return' (fun at -> 
                                   return (fun bt -> f (at >>- (fun a ->
                                                        bt >>- (fun b ->
                                                        return' (a,b))))))
  let eval' (f,x) = f (return' x) >>= return'

  let seval (shrink, f) = return' (fun xs -> shrink xs >>= (fun g -> 
                                             g (xs >>- f)))
 
  let swap f = return' (fun yst -> return (fun x -> f x >>- (fun g -> 
                                                    g yst >>= return')))

  (* The swap' direction is not trivially implementable, give the 
     representation I have chosen. Luckily, we don't need it! *)

  let swap' f = assert false

  (* Right composition relies on the fact that even noncontrative things
     promise to return Some value when given a proper value. *)

  let scomposer f = fun g -> return' (fun cthunk -> g cthunk >>= (fun a -> 
                                                    f a >>= (fun b' -> 
                                                    match b' with
                                                    | None -> assert false
                                                    | Some b -> return b)))
  let scomposel (f : ('a,'b) hom) = fun (g : ('b,'c) shrink) ->
    return' (fun bthunk -> g (bthunk >>- f))

  (* The GUI monad *)

  let return v = return' (fun attach -> return' v)
  let bind f = fun agui -> return' (fun attach ->
                           agui attach >>- f >>- (fun bgui ->
                           bgui attach))
  let strength (a,bgui) = return'(fun attach ->
                                    bgui attach >>- (fun b ->
                                    return'(a,b)))

end                                      

open Code
type 'a omega = 'a option Dataflow.cell
type 'a value = 'a

(* Functorial actions *)

let value (uhom : ('a,'b) U.hom) = fun xs -> cell(read xs >>- uhom)

let omega chom = fun xs -> chom xs >>= return'

(* Unit & Counit *)

let varepsilon = read 
let eta = fun xs -> cell((read xs) >>- (fun _ -> return (Some xs)))

let one' = fun () -> cell(return' ()) >>= return'

let prod xys = cell(read xys >>- (fun (a,b) -> return(Some a))) >>= (fun xs -> 
               cell(read xys >>- (fun (a,b) -> return(Some b))) >>= (fun ys -> 
               return' (xs, ys)))

let prod' = fun (xs,ys) ->
              cell(read xs >>- (fun x -> 
                   read ys >>- (fun y ->
                   return(Some(x,y))))) >>= return'

let oned   = fun v -> return' v
let paird  = fun v -> return' v
let paird' = fun v -> return' v
let apply f = return' (fun x -> return' (f x))

let cons (x : 'a) = 
   return'(fun (xst : 'a value omega option code) -> 
            newref (Some x) >>= (fun (r : 'a option ref) ->
            newref None >>= (fun (xsr : 'a option Dataflow.cell option ref) ->  
            cell(get xsr >>= fun v ->
                (match v with
                 | Some xs -> return(Some xs)
                 | None -> xst >>= (fun xs' ->
                           set xsr xs' >>= (fun () ->
                           return xs'))) >>= (fun (xs' : 'a option Dataflow.cell option) ->
                 ofold (return None) read xs' >>= (fun (newval : 'a option) -> 
                  get r >>= (fun (oldval : 'a option) ->
                 (match oldval with
                 | None -> return newval
                 | Some _ -> set r newval >>= (fun () ->
                             return oldval)))))) >>= (fun output ->
            register output >>= (fun () ->
            return output)))))

(* GUI stuff *)

let label justify labels  = return'(fun attach ->
  local (fun () -> GMisc.label ~justify ~packing:attach ()) >>= (fun w ->
  cell((read labels) >>= (function
       | None -> return ()
       | Some msg -> local (fun () -> w#set_text msg))) >>= (fun setlabel -> 
  register setlabel >>= (fun () ->
  return' () ))))

let button labels = return'(fun attach ->
  local (fun () -> GButton.button ~packing:attach ()) >>= (fun (b : GButton.button) ->
  get_clock >>= (fun clock -> 
  cell (return' false) >>= (fun bsig ->
  cell (read labels >>= (function
        | Some msg -> local (fun () -> b#set_label msg)
        | None -> return ())) >>= (fun setlabel ->
  local (fun () -> b#connect#pressed
           ~callback:(fun () ->
			Dataflow.update bsig (Dataflow.Expr.return (Some true));
			Dataflow.update clock (Dataflow.Expr.return ()))) >>= (fun _ -> 
  local (fun () -> b#connect#released
           ~callback:(fun () ->
			Dataflow.update bsig (Dataflow.Expr.return (Some false));
			Dataflow.update clock (Dataflow.Expr.return ()))) >>= (fun _ -> 
  register setlabel >>= (fun () ->
  return' bsig))))))))

let checkbox labels = return'(fun attach -> 
  local (fun () -> GButton.check_button ~packing:attach ()) >>= (fun (b : GButton.toggle_button) ->
  get_clock >>= (fun clock -> 
  cell (return' false) >>= (fun bsig ->
  cell (read labels >>= (function
        | Some msg -> local (fun () -> b#set_label msg)
        | None -> return ())) >>= (fun setlabel ->
  local (fun () -> b#connect#toggled
           ~callback:(fun () ->
			let b = Dataflow.eval (Dataflow.Expr.read bsig) in 
			Dataflow.update bsig  (Dataflow.Expr.return (omap not b));
		        Dataflow.update clock (Dataflow.Expr.return ()))) >>= (fun _ -> 
  register setlabel >>= (fun () ->
  return' bsig)))))))

let timer () =
  get_clock >>= (fun clock -> 
  return'(fun attach ->
    cell (return' 0) >>= (fun timesig -> 
    local (fun () -> begin
	     let r = ref 0 in
	     Glib.Timeout.add
	       1000
	       (fun () ->
		  let () = incr r in
		  let v = !r in
		  Dataflow.update timesig (Dataflow.Expr.return (Some v));
		  Dataflow.update clock (Dataflow.Expr.return ());
		  true)
	   end) >>= (fun _ -> 
    return' timesig))))
				      

let stack orientation packing homogeneity expand gui =
  let expand = match expand with
    | `EXPAND -> true
    | `NOEXPAND -> false
  in
  let pack_style = match packing with
    | `START -> `START
    | `FINISH -> `END
  in
  let homogeneous = match homogeneity with
    | `HOMOGENEOUS -> true
    | `INHOMOGENEOUS -> false
  in 
  return'(fun attach ->
    local (fun () -> GPack.box orientation ~homogeneous ~packing:attach ()) >>= (fun box -> 
    gui (fun w -> box#pack  ~expand ~from:pack_style w)))

let vstack gui = return'(fun attach -> 
    local (fun () -> GPack.vbox ~packing:attach ()) >>= (fun box -> 
    gui (fun w -> box#pack ~from:`START w)))

let vstack' gui = return'(fun attach -> 
    local (fun () -> GPack.vbox ~packing:attach ()) >>= (fun box -> 
    gui (fun w -> box#pack ~from:`END w)))


let hstack gui = return'(fun attach ->
    local (fun () -> GPack.hbox ~packing:attach ()) >>= (fun box -> 
    gui (fun w -> box#pack ~from:`START w)))

let hstack gui = return'(fun attach ->
    local (fun () -> GPack.hbox ~packing:attach ()) >>= (fun box -> 
    gui (fun w -> box#pack ~from:`END w)))



let fix (f : ('a omega, 'a omega) U.shrink) =
      newref None >>= (fun (r : 'a option ref) ->
      cell(clock >>= (fun () -> get r)) >>= (fun (input : 'a omega) -> 
      register input >>= (fun () -> 
      f (return (Some input)) >>= (fun (pre : 'a omega) -> 
      cell(clock >>= (fun () ->
           read input >>= (fun _ -> 
           read pre >>= (fun v ->
           set r v >>= (fun () ->
           return v))))) >>= (fun output -> 
      register output >>= (fun () -> 
      return' output))))))

let rec hofix f =
  let g v = f v >>= return' in
  Code.fix g

let guifix (f : ('a omega, 'a omega U.gui) U.shrink) =
  return'(fun attach -> 
      newref None >>= (fun (r : 'a option ref) ->
      cell(clock >>= (fun () -> get r)) >>= (fun (input : 'a omega) -> 
      register input >>= (fun () -> 
      f (return (Some input)) >>= (fun (widget : 'a omega U.gui) ->
      widget attach >>- (fun (pre : 'a omega) -> 
      cell(clock >>= (fun () ->
           read input >>= (fun _ -> 
           read pre >>= (fun v ->
           set r v >>= (fun () ->
           return v))))) >>= (fun output -> 
      register output >>= (fun () -> 
      return' output))))))))


let run (uhom : ((C.one omega, U.one) U.prod, 'a U.discrete value omega) U.hom) = 
  let clock = Dataflow.newcell (Dataflow.Expr.return ()) in
  let updates = ref [] in
  let ones = Dataflow.newcell (Dataflow.Expr.return (Some ())) in
  let empty_context = (ones, ()) in 
  let output = match Dataflow.eval (uhom empty_context (clock, updates)) with
               | None -> assert false
               | Some output -> output
  in
  let step () =
    begin
      Dataflow.update clock (Dataflow.Expr.return ());
      let v = Dataflow.eval (Dataflow.Expr.read output) in
      (List.iter Dataflow.eval !updates; v)
    end
  in step

let guirun (f : ((C.one omega, U.one) U.prod, U.one U.gui) U.hom) : unit = 
  let clock = Dataflow.newcell (Dataflow.Expr.return ()) in
  let updates = ref []
  in
  let w = GWindow.window ~border_width:10 () in
  let _ = w#connect#destroy ~callback:GMain.Main.quit in
  let v = GPack.vbox ~packing:w#add ()
  in 
  let ones = Dataflow.newcell (Dataflow.Expr.return (Some ())) in
  let empty_context = (ones, ())
  in 
  let () = match Dataflow.eval (f empty_context (clock,updates)) with
    | None -> assert false
    | Some gui -> (match Dataflow.eval (gui v#add (clock, updates)) with
		   | None -> assert false
		   | Some () -> ())
  in
  let _ = GMain.Idle.add
                (fun () -> List.iter Dataflow.eval (!updates); true) in
  let _ = w#show () in 
    GMain.Main.main ()


(* Lazy implementations.... this is what is in the paper. It's
   provably correct, but inefficient. 

module U =
struct
  (* The lazy implementation of ultrametrics...*)
  open Code

  type one = unit
  type ('a,'b) prod = 'a * 'b
  type ('a,'b) sum = Inl of 'a | Inr of 'b 
  type ('a,'b) exp = 'a option code -> 'b option code
  type ('a,'b) hom = 'a option code -> 'b option code
  type ('a,'b) shrink = 'a option code-> 'b option code
  type 'a discrete = 'a 

  let id x = x
  let compose f g = fun xt -> g(f xt)
  let one = fun _ -> return(Some ())
  let pair f g = fun at -> f at >>- (fun a ->
                             g at >>- (fun b ->
                             return(Some (a,b))))
  let fst = fun abt -> abt >>- (fun (a,b) -> return(Some a))
  let snd = fun abt -> abt >>- (fun (a,b) -> return(Some b))

  (* Double-check case... *)

  let inl thunk = thunk >>- (fun v -> return(Some(Inl v)))
  let inr thunk = thunk >>- (fun v -> return(Some(Inr v)))

  let case (f : ('a,'b) hom) (g : ('c,'b) hom) thunk = thunk >>- (function
                        | Inl v -> f (return (Some v))
                        | Inr v -> g (return (Some v)))

  (* Double-check this to see if we can be more eager her... *)
  let curry f = fun at -> return(Some(fun bt ->
                                  f (at >>- (fun a ->
                                     bt >>- (fun b ->
                                     return (Some(a,b)))))))
  (* Ouch! We get no sharing *at all* *)
  let eval = fun fxt -> (fxt >>- (fun (f,x) ->
                           f (fxt >>- fun (_,x) -> 
                            return (Some x))))
        
  let discrete f xt = xt >>- (fun x ->
                        return (Some (f x)))

  let const x = fun _ -> return(Some x)
    
  (* The contractive operations can be implemented exactly as if
     they were the curried forms of the standard exponential ops.
     This is because we make ZERO effort to be eager. If we
     made any effort in this direction at all, then we would need to
     reimplement these combinators because we would risk losing 
     answers along the pipeline. 
  *)
  let sweak xs = (curry fst) xs

  let spair xs =
    let f = compose (pair (compose fst fst) snd) eval in
    let g = compose (pair (compose fst snd) snd) eval in
    (curry (pair f g)) xs

  let scurry xs =
    let f = compose fst fst in 
    let a = compose fst snd in
    let b = snd in
    let c = compose (pair f (pair a b)) eval in
    (curry (curry c)) xs

  let eval'  = eval 

  let seval xs =
    let f = compose fst fst in
    let g = compose fst snd in
    let a = snd in
    let fa = compose (pair f a) eval in
    let ga = compose (pair g a) eval in
    let c = compose (pair fa ga) eval in
    (curry c) xs

  let swap xs =
    let f = compose fst fst in
    let a = snd in 
    let b = compose fst snd in
    let fa = compose (pair f a) eval in
    let c = compose (pair fa b) eval in
    (curry (curry c)) xs

  let swap' = swap

  let scomposer f = curry (compose eval f)

  let scomposel f = curry (compose (pair fst (compose snd f)) eval)
end                                      

open Code
type 'a omega = 'a option Dataflow.cell
type 'a value = 'a

(* Functorial actions *)

let value uhom = fun xs -> cell(uhom (read xs))

let omega chom = fun xt -> xt >>- (fun xs ->
                             chom xs >>= (fun ys ->
                             return(Some ys)))

(* Unit & Counit *)

let varepsilon xst = xst >>- read
let eta xs = cell((read xs) >>- (fun _ -> return (Some xs)))

let one' _ = 
  cell(return(Some ())) >>= (fun unit ->
  return(Some(unit)))

let prod xycst = xycst >>- (fun xys ->
                   cell(read xys >>- (fun (a,b) -> return(Some a))) >>= (fun xs -> 
                   cell(read xys >>- (fun (a,b) -> return(Some b))) >>= (fun ys -> 
                 return(Some(xs, ys)))))

let prod' xsyst = xsyst >>- (fun (xs,ys) ->
                    cell(read xs >>- (fun x -> 
                         read ys >>- (fun y ->
                         return(Some(x,y))))) >>= (fun xys ->
                    return(Some xys)))

let oned   = fun thunk -> thunk
let paird  = fun thunk -> thunk
let paird' = fun thunk -> thunk

let fix ft = ft >>- (fun (f : ('a omega, 'a omega) U.shrink) ->
               newref None >>= (fun (r : 'a option ref) ->
               cell(clock >>= (fun () -> get r)) >>= (fun (input : 'a omega) -> 
             register input >>= (fun () -> 
             f (return (Some input)) >>= (function
               | None -> assert false 
               | Some (pre : 'a omega) ->  (* sketchy! *)
               cell(clock >>= (fun () ->
                    read input >>= (fun _ -> 
                    read pre >>= (fun v ->
                    set r v >>= (fun () ->
                    return v))))) >>= (fun output -> 
             register output >>= (fun () -> 
             return (Some output))))))))


let cons xt =
  xt >>- (fun x ->
  return(Some(fun xst ->
                  newref (Some x) >>= (fun (r : 'a option ref) ->
                  newref None >>= (fun (xsr : 'a option Dataflow.cell option ref) ->  
                  cell( get r >>= (fun oldval ->
                       (get xsr >>= fun v ->
                        match v with
                        | Some xs -> return(Some xs)
                        | None -> xst >>= (fun xs' ->
                                  set xsr xs' >>= (fun () ->
                                  return xs'))) >>= (fun xs' ->
                       (get xsr >>= (fun xs' ->
                        match xs' with
                        | None -> return None
                        | Some xs -> read xs)) >>= (fun newval ->
                       match oldval with
                       | None -> return newval
                       | Some _ -> set r newval >>= (fun () ->
                                   return oldval))))) >>= (fun output ->
                   register output >>= (fun () ->
                   return (Some output))))))))

let run (uhom : ((C.one omega, U.one) U.prod, 'a U.discrete value omega) U.hom) = 
  let clock = Dataflow.newcell (Dataflow.Expr.return ()) in
  let updates = ref [] in
  let ones = Dataflow.newcell (Dataflow.Expr.return (Some ())) in
  let empty_context = return (Some (ones, ())) in 
  let output = match Dataflow.eval (uhom empty_context (clock, updates)) with
               | None -> assert false
                 | Some output -> output
  in
  let step () =
    begin
      Dataflow.update clock (Dataflow.Expr.return ());
      let v = Dataflow.eval (Dataflow.Expr.read output) in
      (List.iter Dataflow.eval !updates; v)
    end
  in step
*)
